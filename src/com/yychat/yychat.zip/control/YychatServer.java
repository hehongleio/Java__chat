package com.yychat.control;
import java.io.IOException;
import java.net.*;
/*实验11_启动服务器并监听端口,第4步:创建包com.yychat.control后,在包中创建YychatServer类*/
public class YychatServer {
    ServerSocket ss;
    Socket s;
    public YychatServer(){
        try{
            ss=new ServerSocket (3456);
            System.out.println("服务器启动成功,正在监听3456端口...");
            s=ss.accept();//等待客户端连接
            System.out.println("连接成功:"+s);
        } catch (IOException e){
            e.printStackTrace();
        }
    }
}